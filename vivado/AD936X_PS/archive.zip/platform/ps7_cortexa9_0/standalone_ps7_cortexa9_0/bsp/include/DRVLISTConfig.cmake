set(DRIVER_LIST canps;common;coresightps_dcc;devcfg;dmaps;emacps;gpiops;iicps;qspips;scugic;scutimer;scuwdt;sdps;spips;uartps;usbps;xadcps)
